// SPDX-License-Identifier: GPL-3.0-only
// Local ALSA/RTMidi transport for Sven Trogus's ZP12 editor.
"use strict";
const localToken = new URLSearchParams(location.search).get('token') || sessionStorage.getItem('zp12token');
if (localToken) sessionStorage.setItem('zp12token', localToken);
async function api(path, data) {
  const r = await fetch('/api/' + path, {
    method: 'POST', headers: {'Content-Type':'application/json', 'X-ZP12-Token':localToken || ''},
    body: JSON.stringify(data || {})
  });
  const result = await r.json();
  if (!r.ok) throw new Error(result.error || 'Local MIDI service error');
  return result;
}
// Keep the upstream protocol and sample conversion unchanged; replace transport only.
ZP12Link.Link.prototype.request = async function(cmd, addr=0, data=[], len=data.length) {
  const result = await api('request', {frame:ZP12Link.frame(cmd, addr, Array.from(data), len)});
  const reply = ZP12Link.parse(result.frame.slice(1,-1));
  if (!reply || reply.cmd !== cmd || (cmd !== 1 && reply.addr !== addr)) throw new Error('Invalid FM-1 reply');
  return reply;
};
async function refreshLinuxPorts() {
  const status = document.getElementById('linux-status');
  try {
    const p = await api('ports');
    for (const [key, list] of [['midi-in',p.inputs],['midi-out',p.outputs]]) {
      const select=document.getElementById(key), previous=select.value;
      select.replaceChildren(...list.map(name => new Option(name,name)));
      if(list.includes(previous)) select.value=previous;
      else { const likely=list.find(x=>/zp12|fm.?1|felucca|pid.codes/i.test(x)); if(likely)select.value=likely; }
    }
    status.textContent = p.inputs.length && p.outputs.length ? 'Select both FM-1 ports, then Connect the FM-1.' : 'No MIDI ports found. Check USB data cable and normal ZP12 mode.';
  } catch(e) {status.textContent=e.message;}
}
Object.defineProperty(navigator, 'requestMIDIAccess', {value:async function() {
  await api('connect', {input:document.getElementById('midi-in').value, output:document.getElementById('midi-out').value});
  document.getElementById('linux-status').textContent='Linux MIDI ports opened.';
  const input={name:'Local ZP12 input',state:'connected',onmidimessage:null};
  const output={name:'Local ZP12 output',state:'connected',send:()=>{}};
  return {inputs:new Map([['in',input]]),outputs:new Map([['out',output]]),onstatechange:null};
}});
document.addEventListener('DOMContentLoaded',()=>{
  document.getElementById('ports-refresh').onclick=refreshLinuxPorts;
  document.querySelectorAll('a').forEach(a=>{
    if(a.getAttribute('href')?.includes('TOKENPLACEHOLDER')) a.href='/backup.html?token='+encodeURIComponent(localToken || '');
    else if(a.getAttribute('href')==='/') a.href='/?token='+encodeURIComponent(localToken || '');
  });
  refreshLinuxPorts();
});
