#!/usr/bin/env bash
set -e
cd -- "$(dirname -- "$0")"
if [ ! -x .venv/bin/python ]; then
  echo "First run: installing MIDI dependencies into a local virtual environment."
  python3 -m venv .venv || { echo "Install prerequisites: sudo apt install python3-venv"; exit 1; }
fi
if ! .venv/bin/python -c 'import mido, rtmidi' 2>/dev/null; then
  .venv/bin/python -m pip install -r requirements.txt
fi
exec .venv/bin/python app.py "$@"
