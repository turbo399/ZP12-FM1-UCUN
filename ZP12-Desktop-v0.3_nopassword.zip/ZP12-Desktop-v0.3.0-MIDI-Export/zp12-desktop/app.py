#!/usr/bin/env python3
"""ZP12 Linux: local sample editor with RTMidi instead of browser Web MIDI.
SPDX-License-Identifier: GPL-3.0-only
"""
import argparse
import json
import queue
import secrets
import threading
import time
import webbrowser
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

WEB = Path(__file__).resolve().parent / 'web'


def unpack7(data):
    out, acc, bits = bytearray(), 0, 0
    for value in data:
        acc |= value << bits
        bits += 7
        if bits >= 8:
            out.append(acc & 255)
            acc >>= 8
            bits -= 8
    return out


def decode(frame, reply=False):
    if not isinstance(frame, list) or not 4 <= len(frame) <= 640:
        raise ValueError('Invalid MIDI frame length')
    if any(type(v) is not int or not 0 <= v <= 255 for v in frame):
        raise ValueError('Invalid MIDI bytes')
    if frame[0] != 240 or frame[-1] != 247 or any(v > 127 for v in frame[1:-1]):
        raise ValueError('Invalid SysEx framing')
    m = unpack7(frame[1:-1])
    base = 10 if reply else 9
    if len(m) < base + 1 or m[:3] != b'\x7dZP':
        raise ValueError('Not a ZP12 sample-editor frame')
    addr_at = 5 if reply else 4
    addr = int.from_bytes(m[addr_at:addr_at+3], 'little')
    n = int.from_bytes(m[base-2:base], 'little')
    size = n if reply or m[3] == 4 else 0
    if len(m) != base + size + 1 or ((~sum(m[3:-1])) & 255) != m[-1]:
        raise ValueError('Bad ZP12 checksum or length')
    return m[3], addr, n


def validate_request(frame):
    cmd, addr, n = decode(frame)
    if cmd not in range(1, 10) or n > 512:
        raise ValueError('Unsupported sample-editor command')
    if cmd == 2 and not (0x93000 <= addr <= 0x100000-n):
        raise ValueError('Read outside ZP12 data area')
    if cmd in (3, 4):
        size = 4096 if cmd == 3 else n
        ranges = [(0xA0000,0xDC000),(0xE5000,0xE9000),(0xEA000,0xFC000)]
        if not size or not any(lo <= addr and addr+size <= hi for lo,hi in ranges):
            raise ValueError('Write outside ZP12 data area')
        if cmd == 3 and addr % 4096:
            raise ValueError('Erase must be sector aligned')
    return cmd, addr


class MidiBridge:
    def __init__(self, backend=None):
        if backend is None:
            import mido
            backend = mido
        self.mido = backend
        self.lock = threading.Lock()
        self.messages = queue.Queue(maxsize=128)
        self.input = self.output = None

    def ports(self):
        return {'inputs': self.mido.get_input_names(), 'outputs': self.mido.get_output_names()}

    def receive(self, message):
        if message.type == 'sysex':
            try:
                self.messages.put_nowait([240, *message.data, 247])
            except queue.Full:
                pass

    def close(self):
        for port in (self.input, self.output):
            if port:
                port.close()
        self.input = self.output = None

    def connect(self, input_name, output_name):
        with self.lock:
            p = self.ports()
            if input_name not in p['inputs'] or output_name not in p['outputs']:
                raise ValueError('Select an available input AND output MIDI port')
            self.close()
            try:
                self.input = self.mido.open_input(input_name, callback=self.receive)
                self.output = self.mido.open_output(output_name)
            except Exception:
                self.close()
                raise
        return {'connected': True}

    def request(self, frame):
        cmd, addr = validate_request(frame)
        with self.lock:
            if not self.input or not self.output:
                raise ValueError('Connect the MIDI ports first')
            # Serialize all requests, drain stale replies, then match command/address.
            for attempt in range(4):
                while not self.messages.empty():
                    self.messages.get_nowait()
                self.output.send(self.mido.Message('sysex', data=frame[1:-1]))
                deadline = time.monotonic() + 2
                while time.monotonic() < deadline:
                    try:
                        response = self.messages.get(timeout=max(.001, deadline-time.monotonic()))
                    except queue.Empty:
                        break
                    try:
                        rc, ra, _ = decode(response, reply=True)
                    except ValueError:
                        continue
                    if rc == cmd and (cmd == 1 or ra == addr):
                        return {'frame': response}
            raise TimeoutError(f'No ZP12 reply to command {cmd}. Check selected ports; close other MIDI apps. Device must run ZP12 normally.')


def make_handler(bridge, token):
    class Handler(SimpleHTTPRequestHandler):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, directory=str(WEB), **kwargs)

        def log_message(self, fmt, *args):
            pass

        def answer(self, code, body):
            data = json.dumps(body).encode()
            self.send_response(code)
            self.send_header('Content-Type','application/json')
            self.send_header('Cache-Control','no-store')
            self.send_header('Content-Length',str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def do_POST(self):
            if not secrets.compare_digest(self.headers.get('X-ZP12-Token',''), token):
                self.answer(403, {'error':'Launch the app using the URL printed in the terminal.'})
                return
            try:
                size = int(self.headers.get('Content-Length',0))
                if not 0 < size <= 8192:
                    raise ValueError('Invalid request size')
                data = json.loads(self.rfile.read(size))
                if self.path == '/api/ports':
                    result = bridge.ports()
                elif self.path == '/api/connect':
                    result = bridge.connect(data.get('input'),data.get('output'))
                elif self.path == '/api/request':
                    result = bridge.request(data.get('frame'))
                else:
                    self.answer(404, {'error':'Unknown command'})
                    return
                self.answer(200,result)
            except Exception as e:
                self.answer(400,{'error':str(e)})
    return Handler


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--port',type=int,default=0, help='Local port (default: choose a free port)')
    parser.add_argument('--no-browser',action='store_true')
    args = parser.parse_args()
    try:
        bridge = MidiBridge()
        bridge.ports()
    except Exception as e:
        raise SystemExit(f'MIDI unavailable: {e}\nRun ./launch.sh; on Pop!_OS ensure /dev/snd/seq exists (sudo modprobe snd-seq-midi).')
    token = secrets.token_urlsafe(24)
    server = ThreadingHTTPServer(('127.0.0.1',args.port),make_handler(bridge,token))
    url = f'http://127.0.0.1:{server.server_port}/?token={token}'
    print('ZP12 Linux Sample Manager — local MIDI connection\n'+url+'\nKeep this terminal open. Ctrl+C quits.',flush=True)
    if not args.no_browser:
        webbrowser.open(url)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
        bridge.close()


if __name__ == '__main__':
    main()
