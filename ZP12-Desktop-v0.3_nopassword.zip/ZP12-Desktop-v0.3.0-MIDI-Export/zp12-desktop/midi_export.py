#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-only
"""Export saved ZP12 loops from .zp12bak to Standard MIDI Files (no dependencies)."""
import argparse
import struct
import zlib
from dataclasses import dataclass
from pathlib import Path

BASE, SLOT = 0xC4000, 0xA000
PPQ = 96
SWING = (50,54,58,63,67,71)

@dataclass
class Hit:
    tick: int
    pad: int
    velocity: int
    semitones: int
    locked: bool

@dataclass
class Loop:
    bars: int
    hits: list

@dataclass
class Project:
    bpm10: int
    quant: int
    swing: int
    loops: list
    generation: int


def backup_sectors(data):
    if len(data)<36 or data[:8]!=b'ZP12BAK1':
        raise ValueError('Choose a ZP12 .zp12bak backup, not a WAV or firmware file.')
    if zlib.crc32(data[:-4]) != struct.unpack_from('<I',data,len(data)-4)[0]:
        raise ValueError('Backup checksum failed. Make another backup before exporting.')
    def word(offset):
        if offset+4>len(data)-4: raise ValueError('Truncated backup')
        return struct.unpack_from('<I',data,offset)[0]
    nr=word(24)
    if not 1<=nr<=16: raise ValueError('Invalid backup range count')
    pos=28; ranges=[]
    for _ in range(nr):
        lo,hi,part=word(pos),word(pos+4),word(pos+8);pos+=12
        if lo>=hi or hi>0x100000 or lo%4096 or hi%4096 or part not in (0,1):
            raise ValueError('Invalid backup range')
        ranges.append((lo,hi,part))
    if not any(part==0 and lo<=BASE and hi>=BASE+2*SLOT for lo,hi,part in ranges):
        raise ValueError('This backup has no ZP12 patterns. Include ZP12 when backing up.')
    ns=word(pos);pos+=4
    if ns>256 or pos+ns*4100+4!=len(data): raise ValueError('Invalid backup sector length')
    sectors={}
    for _ in range(ns):
        address=word(pos);pos+=4
        if address%4096 or address in sectors or not any(lo<=address and address+4096<=hi for lo,hi,_ in ranges):
            raise ValueError('Invalid or duplicate backup sector')
        sectors[address]=data[pos:pos+4096];pos+=4096
    return sectors


def parse_record(payload,version,generation):
    # ZP12 sp_store.c: 32 x 18-byte sounds, 8 faders, 20 FX bytes,
    # 8 uint16 settings, 4 x 32 x 2-byte song steps, 4 song lengths, 8 UI bytes.
    if version not in (4,5,6): raise ValueError('Unsupported ZP12 save version (supported: 4–6).')
    if len(payload)<888+16*4: raise ValueError('Truncated ZP12 pattern record')
    st=struct.unpack_from('<8H',payload,604)
    if not 400<=st[0]<=2400 or st[1]>6 or st[2]>5:
        raise ValueError('Invalid saved tempo/quantize/swing settings')
    pos=888; loops=[];locks=0
    for _ in range(16):
        if pos+4>len(payload): raise ValueError('Truncated loop header')
        bars,_,n=struct.unpack_from('<BBH',payload,pos);pos+=4
        if bars>32 or n>512 or pos+4*n>len(payload): raise ValueError('Invalid loop size')
        hits=[]
        for _ in range(n):
            event=struct.unpack_from('<I',payload,pos)[0];pos+=4
            tick=event&0x3fff;pad=(event>>14)&31;level=(event>>19)&7
            semi=(event>>23)&63;semi=semi-64 if semi&32 else semi
            locked=bool(event&(1<<29));locks+=locked
            if tick>=384*(bars or 1): raise ValueError('Hit outside its saved loop length')
            hits.append(Hit(tick,pad,(level+1)*16-1,semi,locked))
        loops.append(Loop(bars or 1,hits))
    # Locks are optional when firmware ran out of save room; playback clears absent locks.
    if (len(payload)-pos)%4: raise ValueError('Invalid parameter-lock data')
    if len(payload)-pos>locks*4: raise ValueError('Unexpected data after ZP12 loops')
    return Project(st[0],st[1],st[2],loops,generation)


def read_project(data):
    sectors=backup_sectors(data)
    empty=b'\xff'*4096
    def read(address,n):
        return bytes(sectors.get(a&~4095,empty)[a&4095] for a in range(address,address+n))
    candidates=[];errors=[]
    for address in (BASE,BASE+SLOT):
        magic,version,generation,length,crc=struct.unpack('<5I',read(address,20))
        if magic!=0x3231505a:continue
        if length>SLOT-20: errors.append('Invalid saved-record length');continue
        payload=read(address+20,length)
        if zlib.crc32(payload)!=crc:errors.append('Saved-record checksum failed');continue
        try:candidates.append(parse_record(payload,version,generation))
        except ValueError as e:errors.append(str(e))
    if not candidates:
        raise ValueError('No valid saved patterns found. '+(' / '.join(errors) if errors else 'Press SAVE on ZP12, then make a fresh backup.'))
    return max(candidates,key=lambda p:p.generation)


def vlq(n):
    if not 0<=n<=0xfffffff:raise ValueError('MIDI time outside supported range')
    out=[n&127]
    while n>>7:
        n>>=7;out.insert(0,(n&127)|128)
    return bytes(out)


def track(events,end_tick):
    events=sorted(events,key=lambda x:(x[0],x[1]))
    result=bytearray();last=0
    for tick,_,message in events:
        result+=vlq(tick-last)+message;last=tick
    result+=vlq(max(end_tick,last)-last)+b'\xff\x2f\x00'
    return b'MTrk'+struct.pack('>I',len(result))+result


def export_loop(project,index,channel=1,split=True,swing=True):
    if not 0<=index<16 or not 1<=channel<=16:raise ValueError('Invalid loop or MIDI channel')
    loop=project.loops[index]
    if not loop.hits:raise ValueError('That loop contains no saved notes')
    tempo=round(600000000/project.bpm10)
    name=f'ZP12 Loop {index+1}'.encode('ascii')
    conductor=[(0,0,b'\xff\x03'+vlq(len(name))+name),
               (0,1,b'\xff\x51\x03'+tempo.to_bytes(3,'big')),
               (0,2,b'\xff\x58\x04\x04\x02\x18\x08')]
    end=loop.bars*384; groups={}
    for hit in loop.hits:
        tick=hit.tick
        grid=48 if project.quant==1 else 24
        if swing and tick%(2*grid)==grid:
            tick+=(2*grid)*(SWING[project.swing]-50)//100
        key=hit.pad if split else 0
        group=groups.setdefault(key,[])
        group.extend([(tick,2,bytes([0x90+channel-1,36+hit.pad,hit.velocity])),
                      (min(tick+6,end),1,bytes([0x80+channel-1,36+hit.pad,0]))])
    tracks=[track(conductor,end)]
    for pad,events in sorted(groups.items()):
        label=(f'{chr(65+pad//8)}{pad%8+1} — note {36+pad}' if split else 'ZP12 kit').encode('utf-8')
        events.insert(0,(0,0,b'\xff\x03'+vlq(len(label))+label))
        tracks.append(track(events,end))
    return b'MThd'+struct.pack('>IHHH',6,1,len(tracks),PPQ)+b''.join(tracks)


def warnings_for(loop):
    result=[]
    if any(h.semitones for h in loop.hits):result.append('MULTI PITCH transpositions are not exported; notes trigger the original pads.')
    if any(h.locked for h in loop.hits):result.append('Per-hit pitch/decay/filter locks are not exported.')
    return result


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('backup',type=Path);p.add_argument('--loop',type=int,help='Loop 1–16 (omit to list)')
    p.add_argument('--output',type=Path);p.add_argument('--channel',type=int,default=1)
    p.add_argument('--single-track',action='store_true');p.add_argument('--straight',action='store_true')
    a=p.parse_args();project=read_project(a.backup.read_bytes())
    if a.loop is None:
        print(f'Tempo: {project.bpm10/10:g} BPM')
        for i,loop in enumerate(project.loops):
            if loop.hits:print(f'Loop {i+1}: {loop.bars} bars, {len(loop.hits)} hits')
        return
    if not 1<=a.loop<=16:p.error('--loop must be 1–16')
    target=a.output or a.backup.with_name(a.backup.stem+f'-loop-{a.loop}.mid')
    if target.resolve()==a.backup.resolve():p.error('Output must not overwrite the backup')
    target.write_bytes(export_loop(project,a.loop-1,a.channel,not a.single_track,not a.straight))
    print('Saved:',target)
    for warning in warnings_for(project.loops[a.loop-1]):print('Note:',warning)

if __name__=='__main__':
    try:main()
    except (ValueError,OSError) as e:raise SystemExit(str(e))
