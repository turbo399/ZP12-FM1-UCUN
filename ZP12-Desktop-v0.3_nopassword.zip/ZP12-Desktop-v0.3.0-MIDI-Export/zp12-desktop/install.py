#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-only
"""Install desktop edition per user, no sudo or system Python changes."""
import os
from pathlib import Path
import shutil
import subprocess
import sys

def desktop_quote(value):
    s=str(value).replace('%','%%')
    for char in ('\\','"','`','$'):
        s=s.replace(char,'\\'+char)
    return '"'+s+'"'

def main():
    source=Path(__file__).resolve().parent
    data=Path(os.environ.get('XDG_DATA_HOME',Path.home()/'.local/share'))
    target=data/'zp12-sample-manager'
    target.mkdir(parents=True,exist_ok=True)
    if source!=target.resolve():
        shutil.copytree(source,target,dirs_exist_ok=True,
            ignore=shutil.ignore_patterns('.venv','.git','__pycache__','*.pyc','dist','build'))
    python=target/'.venv/bin/python'
    if not python.exists():
        subprocess.run([sys.executable,'-m','venv',str(target/'.venv')],check=True)
    print('Installing desktop dependencies (first installation downloads Qt; this may take a few minutes).',flush=True)
    subprocess.run([str(python),'-m','pip','install','-r',str(target/'requirements-desktop.txt')],check=True)
    for name in ('start-desktop.sh','launch.sh','install.sh'):
        p=target/name;p.chmod(p.stat().st_mode|0o111)
    icon=data/'icons/hicolor/scalable/apps/zp12-sample-manager.svg'
    icon.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(target/'icon.svg',icon)
    menu=data/'applications';menu.mkdir(parents=True,exist_ok=True)
    (menu/'zp12-sample-manager.desktop').write_text(
        '[Desktop Entry]\nType=Application\nName=ZP12 Sample Manager\n'
        'Comment=FM-1 sample editor — standalone desktop edition\n'
        'Exec=bash '+desktop_quote(target/'start-desktop.sh')+'\n'
        'Icon=zp12-sample-manager\nTerminal=false\nCategories=AudioVideo;Audio;\n'
        'Keywords=FM1;Sampler;MIDI;ZP12;\nStartupWMClass=zp12-sample-manager\n')
    if shutil.which('update-desktop-database'):
        subprocess.run(['update-desktop-database',str(menu)],check=False)
    print('\nInstalled. Search Applications for ZP12 Sample Manager. No terminal is needed to run it.')

if __name__=='__main__':
    try:main()
    except subprocess.CalledProcessError as e:
        raise SystemExit('Installation failed. Keep the error above. On Ubuntu/Pop!_OS install python3-venv first.') from e
