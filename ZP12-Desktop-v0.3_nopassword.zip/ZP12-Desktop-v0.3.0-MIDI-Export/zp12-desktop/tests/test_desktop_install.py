# SPDX-License-Identifier: GPL-3.0-only
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import install

class InstallerTests(unittest.TestCase):
    def test_install_to_stable_path_and_desktop_entry(self):
        with tempfile.TemporaryDirectory(prefix='zp12 install ') as temp:
            with patch.dict(os.environ,{'XDG_DATA_HOME':temp}), patch('install.subprocess.run') as run:
                install.main()
            target=Path(temp)/'zp12-sample-manager'
            entry=(Path(temp)/'applications/zp12-sample-manager.desktop').read_text()
            self.assertIn('Terminal=false',entry)
            self.assertIn(str(target/'start-desktop.sh'),entry)
            self.assertTrue((target/'desktop.py').is_file())
            self.assertTrue((Path(temp)/'icons/hicolor/scalable/apps/zp12-sample-manager.svg').is_file())
            self.assertFalse((target/'__pycache__').exists())
            self.assertTrue(any('pip' in str(c) for c in run.call_args_list))

if __name__=='__main__':unittest.main()
