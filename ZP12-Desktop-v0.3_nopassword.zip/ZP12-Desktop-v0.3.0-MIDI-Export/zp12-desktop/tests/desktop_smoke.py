# SPDX-License-Identifier: GPL-3.0-only
"""Offscreen Qt test with simulated MIDI. PySide6 required; no real device used.
QT_QPA_PLATFORM=offscreen QTWEBENGINE_CHROMIUM_FLAGS='--no-sandbox --disable-gpu' python3 tests/desktop_smoke.py
"""
import json
from pathlib import Path
import sys
import tempfile
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from PySide6.QtWidgets import QApplication
from PySide6.QtCore import QEventLoop,QTimer
import shiboken6
from desktop import Window
from test_bridge import FakeMidi,MidiBridge

app=QApplication([])
window=Window(MidiBridge(FakeMidi()))
window.show()

def wait_for(test, timeout=15000):
    loop=QEventLoop();timer=QTimer();timer.setInterval(25)
    timer.timeout.connect(lambda:loop.quit() if test() else None)
    deadline=QTimer();deadline.setSingleShot(True);deadline.timeout.connect(loop.quit)
    timer.start();deadline.start(timeout);loop.exec();timer.stop()
    assert test(),'timed out'

def js(code):
    result=[]
    window.page.runJavaScript(code,lambda value:result.append(value))
    wait_for(lambda:bool(result))
    return result[0]

try:
    ready=[]
    window.view.loadFinished.connect(lambda ok:ready.append(ok))
    wait_for(lambda:bool(ready));assert ready[-1]
    wait_for(lambda:js("document.querySelector('#midi-in').options.length")>0)
    js("document.querySelector('#connect').click()")
    wait_for(lambda:js("document.querySelector('#lcd').textContent.includes('CONNECTED')"))
    js("""window.qa='running';(async()=>{
      const d=await Z.readDir(link);
      const slot=await Z.upload(link,d,{y:new Int16Array([0,1000,-1000,2047,-2048]),rate:26040,name:'QTTEST'});
      await link.assign(0,link.info.kit+slot);
      const fresh=await Z.readDir(link);
      const values=await Z.fetchSample(link,fresh.slots[slot]);
      window.qa=JSON.stringify(Array.from(values));
    })().catch(e=>window.qa='ERROR '+e.message)""")
    wait_for(lambda:js("window.qa!=='running'"))
    assert json.loads(js('window.qa'))==[0,1000,-1000,2047,-2048]
    with tempfile.TemporaryDirectory() as temp:
        dest=Path(temp)/'qt-export.wav'
        with patch('desktop.QFileDialog.getSaveFileName',return_value=(str(dest),'')):
            js("save(Z.wav(new Int16Array([0,1000,-1000]),26040),'qt-export.wav')")
            wait_for(lambda:dest.exists() and dest.stat().st_size>44)
        assert dest.read_bytes()[:4]==b'RIFF'
        dest=Path(temp)/'qt-backup.zp12bak'
        with patch('desktop.QFileDialog.getSaveFileName',return_value=(str(dest),'')):
            js("Z.backup(link,['zp12']).then(bytes=>save(bytes,'qt-backup.zp12bak')).catch(e=>window.qa=e.message)")
            wait_for(lambda:dest.exists() and dest.stat().st_size>36,30000)
        assert dest.read_bytes()[:8]==b'ZP12BAK1'
    from test_midi_export import ExportTests
    ExportTests.setUpClass()
    with tempfile.TemporaryDirectory() as temp:
        source=Path(temp)/'groove.zp12bak';source.write_bytes(ExportTests.backup)
        dest=Path(temp)/'groove.mid'
        with patch('desktop.QFileDialog.getOpenFileName',return_value=(str(source),'')), \
             patch('desktop.QInputDialog.getItem',side_effect=[('Loop 1 — 2 bars, 4 hits',True),('Separate tracks for each pad (same MIDI channel 1)',True)]), \
             patch('desktop.QFileDialog.getSaveFileName',return_value=(str(dest),'')), \
             patch('desktop.QMessageBox.information'):
            window.export_midi()
        assert dest.read_bytes()[:4]==b'MThd'
    print('PASS: native MIDI-export dialogs and file creation')
    screenshot=Path('/tmp/zp12-desktop-smoke.png')
    window.grab().save(str(screenshot))
    window.navigate('/backup.html')
    wait_for(lambda:js("!!document.querySelector('#b-banks')"))
    print('PASS: Qt window, port discovery, connection, upload/readback, WAV save, backup save, backup navigation')
finally:
    window.server.shutdown();window.server.server_close();window.bridge.close()
    shiboken6.delete(window.page);shiboken6.delete(window.profile)
    window.closing=True;window.close()
