/* SPDX-License-Identifier: GPL-3.0-only
 * Save layout and zs_pack from zvenson/zp12 a7cc3dcf3b59303024dcfb69f34aac98007425c5.
 * Host fixture checks our decoder against the original C serializer. */
#include <stdint.h>
#include <string.h>
#include <stdio.h>
#define SQ_MAXEV 512
#define SQ_NSEG 16
#define ZS_SLOT 0xA000
#define ZS_KIT_ID 1234
#define SP_NSOUND 32
typedef struct {                        /* a sound (a pad) */
    uint8_t wave;                       /* index into sp_wave[] (0xFF: none) */
    int8_t tune;                        /* semitones -24..+12 */
    int8_t fine;                        /* cents -50..+50 */
    uint8_t decay;                      /* 0 short .. 127 the whole sound */
    uint8_t level;                      /* 0..127 */
    int8_t pan;                         /* -64..63 */
    uint8_t chan;                       /* 0..7 */
    uint8_t flags;                      /* SPF_* */
    uint16_t start, end;                /* truncate, 0..SP_TR of the wave (end SP_TR = its end) */
    uint8_t cut, reso;                  /* channels 1-2: cutoff 0..127, resonance 0..127 */
    uint8_t drive;                      /* 0..127: the channel's input driven into a soft clip */
    uint8_t send[3];                    /* chorus, delay, reverb sends 0..127 (sp_fx.c) */
} sp_sound_t;
typedef struct {
    uint32_t t : 14;                            /* tick in the segment (32 bars = 12288) */
    uint32_t pad : 5;
    uint32_t lvl : 3;                           /* 0..7: velocity (lvl + 1) * 16 - 1 */
    uint32_t skip : 1;
    int32_t semis : 6;                          /* -32..31 */
    uint32_t lk : 1;                            /* its lock in sq_lk */
    uint32_t rsv : 2;
} sq_ev_t;
typedef struct { uint8_t bars, rsv; uint16_t n; sq_ev_t ev[SQ_MAXEV]; } sq_seg_t;   /* bars 0: AUTO; ev by t */


typedef struct { uint32_t magic,ver,gen,len,crc; } zs_head_t;
static sp_sound_t sp_sound[32];
static uint8_t sp_mix[8];
static struct {int16_t crate,cdepth,cmix,dtime,fdbk,colr,dmix,size,damp,pre;} fxp;
static struct {uint16_t bpm10,quant,swing,click,song_sel,song_mode,seg,cin_bars,dub_bar;} sq;
static struct {uint8_t back;} ui;
static uint8_t sp_smooth;
static struct {uint8_t seg,rep;} sq_songs[4][32];
static uint8_t sq_song_len[4];
static sq_seg_t sq_seg[16];
static uint32_t sq_lk[16][512];
static uint32_t zs_crc(const uint8_t *p, uint32_t n)
{
    uint32_t c = 0xFFFFFFFFu, k;
    while (n--) {
        c ^= *p++;
        for (k = 0; k < 8u; k++)
            c = (c >> 1) ^ (0xEDB88320u & (0u - (c & 1u)));
    }
    return ~c;
}

static uint8_t *zs_put(uint8_t *p, const void *s, uint32_t n) { memcpy(p, s, n); return p + n; }
static uint32_t zs_pack(uint8_t *b)
{
    uint8_t *p = b, *e = b + ZS_SLOT - sizeof(zs_head_t);
    uint32_t i, j;
    uint16_t st[8] = {sq.bpm10, sq.quant, sq.swing, sq.click, sq.song_sel, sq.song_mode, sq.seg, ZS_KIT_ID};
    p = zs_put(p, sp_sound, sizeof sp_sound);
    p = zs_put(p, sp_mix, sizeof sp_mix);
    p = zs_put(p, &fxp, sizeof fxp);
    p = zs_put(p, st, sizeof st);
    p = zs_put(p, sq_songs, sizeof sq_songs);
    p = zs_put(p, sq_song_len, sizeof sq_song_len);
    {
        uint16_t u[4] = {ui.back, (uint16_t)(sp_smooth + 1u), (uint16_t)(sq.cin_bars + 1u), (uint16_t)(sq.dub_bar + 1u)};   /* (0: an older save) */
        p = zs_put(p, u, sizeof u);
    }
    for (i = 0; i < SQ_NSEG; i++) {
        const sq_seg_t *s = &sq_seg[i];
        p = zs_put(p, s, 4u);                    /* bars, rsv, n */
        p = zs_put(p, s->ev, s->n * sizeof(sq_ev_t));
    }
    for (i = 0; i < SQ_NSEG; i++)
        for (j = 0; j < sq_seg[i].n; j++)
            if (sq_seg[i].ev[j].lk && e - p >= 4)
                p = zs_put(p, &sq_lk[i][j], 4u);
    return (uint32_t)(p - b);
}


int main(void) {
 if(sizeof(sp_sound_t)!=18 || sizeof(sq_ev_t)!=4 || sizeof(fxp)!=20)return 2;
 uint8_t b[ZS_SLOT]={0};
 sq.bpm10=1375;sq.quant=3;sq.swing=3;
 sq_seg[0].bars=2;sq_seg[0].n=4;
 sq_seg[0].ev[0]=(sq_ev_t){.t=0,.pad=0,.lvl=7};
 sq_seg[0].ev[1]=(sq_ev_t){.t=24,.pad=2,.lvl=3};
 sq_seg[0].ev[2]=(sq_ev_t){.t=96,.pad=1,.lvl=6,.semis=-12,.lk=1};
 sq_seg[0].ev[3]=(sq_ev_t){.t=384,.pad=31,.lvl=1,.skip=1};
 sq_lk[0][2]=123456;
 sq_seg[8].bars=1;sq_seg[8].n=1;
 sq_seg[8].ev[0]=(sq_ev_t){.t=360,.pad=8,.lvl=4};
 uint32_t n=zs_pack(b+20);
 zs_head_t h={0x3231505a,6,10,n,zs_crc(b+20,n)};
 memcpy(b,&h,20);fwrite(b,1,20+n,stdout);return 0;
}
