// SPDX-License-Identifier: GPL-3.0-only
// Run while tests/ui_fixture.py is serving on localhost:18765.
const assert = require('node:assert/strict');
const Z = require('../web/zp12link.js');
const link = new Z.Link(()=>{});
link.request = async (cmd, addr=0, data=[], len=data.length) => {
  const r = await fetch('http://127.0.0.1:18765/api/request', {
    method:'POST',headers:{'Content-Type':'application/json','X-ZP12-Token':'ui-test'},
    body:JSON.stringify({frame:Z.frame(cmd,addr,Array.from(data),len)})
  });
  const body=await r.json();
  if(!r.ok)throw new Error(body.error);
  return Z.parse(body.frame.slice(1,-1));
};
(async()=>{
  await fetch('http://127.0.0.1:18765/api/connect',{method:'POST',headers:{'Content-Type':'application/json','X-ZP12-Token':'ui-test'},body:JSON.stringify({input:'zp12 FM-1 MIDI 1',output:'zp12 FM-1 MIDI 1'})});
  const h=await link.hello(); assert.equal(h.proto,5); assert.equal(h.kit,27);
  const d=await Z.readDir(link); const before=d.slots.filter(Boolean).length;
  const signal=Int16Array.from({length:2604},(_,i)=>Math.round(Math.sin(i*.1)*1900));
  const slot=await Z.upload(link,d,{y:signal,rate:26040,name:'LINUXQA'},false);
  await link.assign(0,h.kit+slot);
  const fresh=await Z.readDir(link);
  assert.equal(fresh.slots[slot].name,'LINUXQA');
  assert.deepEqual(await Z.fetchSample(link,fresh.slots[slot]),signal);
  assert.equal((await link.pads()).waves[0],h.kit+slot);
  const wav=Z.wav(signal,26040);assert.equal(Buffer.from(wav.slice(0,4)).toString(),'RIFF');
  const backup=await Z.backup(link,['zp12']);
  assert(Z.readBackup(backup).parts.has('zp12'));
  await Z.remove(link,fresh,slot);
  assert.equal((await Z.readDir(link)).slots.filter(Boolean).length,before);
  console.log('PASS: HTTP/native bridge: HELLO, directory, upload, readback, pad assignment, WAV, backup, deletion');
})().catch(e=>{console.error(e);process.exitCode=1;});
