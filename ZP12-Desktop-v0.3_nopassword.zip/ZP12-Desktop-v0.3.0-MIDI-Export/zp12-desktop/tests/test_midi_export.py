# SPDX-License-Identifier: GPL-3.0-only
import io
from pathlib import Path
import shutil
import struct
import subprocess
import sys
import tempfile
import unittest
import zlib
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from midi_export import read_project,export_loop,warnings_for,backup_sectors

def make_backup(record, second=None):
    sectors={}
    for base,blob in [(0xc4000,record),(0xce000,second)]:
        if blob is None:continue
        for offset in range(0,len(blob),4096):
            sectors[base+offset]=blob[offset:offset+4096].ljust(4096,b'\xff')
    data=b'ZP12BAK1'+b'zp12 2.5'.ljust(16,b'\0')
    data+=struct.pack('<I3II',1,0xc4000,0xdc000,0,len(sectors))
    for address,sector in sorted(sectors.items()):data+=struct.pack('<I',address)+sector
    return data+struct.pack('<I',zlib.crc32(data))

@unittest.skipUnless(shutil.which('cc'),'C compiler required for upstream serializer fixture')
class ExportTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        with tempfile.TemporaryDirectory() as temp:
            binary=Path(temp)/'fixture'
            subprocess.run(['cc','-O2',str(Path(__file__).with_name('firmware_save_fixture.c')),'-o',str(binary)],check=True)
            cls.record=subprocess.check_output([str(binary)])
        cls.backup=make_backup(cls.record)

    def test_original_serializer_layout_and_bitfields(self):
        p=read_project(self.backup)
        self.assertEqual((p.bpm10,p.swing,p.quant,p.generation),(1375,3,3,10))
        loop=p.loops[0]
        self.assertEqual(loop.bars,2)
        self.assertEqual([(h.tick,h.pad,h.velocity) for h in loop.hits],[(0,0,127),(24,2,63),(96,1,111),(384,31,31)])
        self.assertEqual(loop.hits[2].semitones,-12)
        self.assertEqual(len(warnings_for(loop)),2)
        self.assertEqual(p.loops[8].hits[0].pad,8)

    def test_valid_midi_header_note_mapping_and_loop_length(self):
        p=read_project(self.backup);m=export_loop(p,0)
        self.assertEqual(m[:14],b'MThd'+struct.pack('>IHHH',6,1,5,96))
        self.assertIn(b'\x90\x24\x7f',m)
        self.assertIn(b'\x90\x43\x1f',m)
        self.assertEqual(m.count(b'MTrk'),5)
        # Independent MIDI decoder, when available, checks timing, swing and tempo.
        try:import mido
        except ImportError:return
        mid=mido.MidiFile(file=io.BytesIO(m));hits=[]
        for track in mid.tracks:
            tick=0
            for event in track:
                tick+=event.time
                if event.type=='note_on':hits.append((tick,event.note,event.velocity,event.channel))
            self.assertEqual(tick,768)
        self.assertEqual(sorted(hits),[(0,36,127,0),(30,38,63,0),(96,37,111,0),(384,67,31,0)])
        self.assertEqual(mid.tracks[0][1].tempo,round(600000000/1375))

    def test_single_track_straight_channel_and_second_loop(self):
        p=read_project(self.backup);m=export_loop(p,8,channel=10,split=False,swing=False)
        self.assertEqual(struct.unpack_from('>H',m,10)[0],2)
        self.assertIn(b'\x99\x2c\x4f',m)

    def test_crc_failure_and_bad_bounds(self):
        bad=bytearray(self.backup);bad[80]^=1
        with self.assertRaisesRegex(ValueError,'checksum'):read_project(bad)
        with self.assertRaises(ValueError):backup_sectors(b'ZP12BAK1')
        with self.assertRaises(ValueError):export_loop(read_project(self.backup),1)

    def test_fallback_from_corrupt_newest_copy(self):
        newer=bytearray(self.record);struct.pack_into('<I',newer,8,11);newer[-1]^=1
        self.assertEqual(read_project(make_backup(self.record,newer)).generation,10)

    def test_newest_good_copy_selected(self):
        newer=bytearray(self.record);struct.pack_into('<I',newer,8,11)
        self.assertEqual(read_project(make_backup(self.record,newer)).generation,11)

if __name__=='__main__':unittest.main()
