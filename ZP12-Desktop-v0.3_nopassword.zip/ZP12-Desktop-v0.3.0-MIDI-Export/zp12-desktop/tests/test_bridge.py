# SPDX-License-Identifier: GPL-3.0-only
import sys
import threading
import unittest
import urllib.request
import urllib.error
import json
from pathlib import Path
from types import SimpleNamespace
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from app import MidiBridge, ThreadingHTTPServer, make_handler, decode, validate_request

def pack7(data):
    out, acc, bits = [], 0, 0
    for b in data:
        acc |= b << bits
        bits += 8
        while bits >= 7:
            out.append(acc & 127)
            acc >>= 7
            bits -= 7
    if bits:
        out.append(acc & 127)
    return out

def request(cmd, addr=0, data=b'', count=None):
    n = len(data) if count is None else count
    raw = bytearray(b'\x7dZP')+bytes([cmd])+addr.to_bytes(3,'little')+n.to_bytes(2,'little')+data
    raw.append((~sum(raw[3:])) & 255)
    return [240,*pack7(raw),247]

class FakeMidi:
    """In-memory NOR and sample editor replies; no real MIDI ports used."""
    def __init__(self):
        self.memory=bytearray(b'\xff'*0x100000)
        self.assignments=[0]*32
        self.callback=None
    def get_input_names(self): return ['zp12 FM-1 MIDI 1']
    def get_output_names(self): return ['zp12 FM-1 MIDI 1']
    def open_input(self,name,callback):
        self.callback=callback
        return SimpleNamespace(close=lambda:None)
    def open_output(self,name): return SimpleNamespace(close=lambda:None,send=self.send)
    def Message(self,kind,data): return SimpleNamespace(type=kind,data=data)
    def send(self,msg):
        from app import unpack7
        raw=unpack7(msg.data)
        cmd,addr,n=decode([240,*msg.data,247])
        data=b''
        if cmd==1: data=b'\x05zp12 2.5\0\x1b'
        elif cmd==2: data=self.memory[addr:addr+n]
        elif cmd==3: self.memory[addr:addr+4096]=b'\xff'*4096
        elif cmd==4:
            for i,b in enumerate(raw[9:9+n]): self.memory[addr+i] &= b
        elif cmd==7: data=b'\x01'
        elif cmd==8: self.assignments[addr&31]=(addr>>8)&63
        elif cmd==9: data=bytes(self.assignments)+b'KICK\0'*27
        reply=bytearray(b'\x7dZP')+bytes([cmd,0])+addr.to_bytes(3,'little')+len(data).to_bytes(2,'little')+data
        reply.append((~sum(reply[3:]))&255)
        self.callback(self.Message('sysex',pack7(reply)))

class BridgeTests(unittest.TestCase):
    def setUp(self):
        self.fake=FakeMidi()
        self.bridge=MidiBridge(self.fake)
        self.bridge.connect('zp12 FM-1 MIDI 1','zp12 FM-1 MIDI 1')
    def test_hello_new_device_name(self):
        r=self.bridge.request(request(1))
        self.assertEqual(decode(r['frame'],True),(1,0,11))
    def test_erase_write_read_and_assignment(self):
        self.bridge.request(request(3,0xea000))
        self.bridge.request(request(4,0xea000,b'\x00\xff\x81\x7f'))
        r=self.bridge.request(request(2,0xea000,count=4))
        from app import unpack7
        self.assertEqual(unpack7(r['frame'][1:-1])[10:14],b'\x00\xff\x81\x7f')
        self.bridge.request(request(8,2|(27<<8)))
        self.assertEqual(self.fake.assignments[2],27)
    def test_reject_wrong_ports(self):
        with self.assertRaises(ValueError): self.bridge.connect('other','other')
    def test_firmware_writes_blocked(self):
        for frame in [request(3,0),request(4,0x4000,b'X'),request(3,0xea001),request(2,0,count=1)]:
            with self.assertRaises(ValueError): validate_request(frame)
    def test_damaged_frame_rejected(self):
        frame=request(4,0xea000,b'abc'); frame[3]^=1
        with self.assertRaises(ValueError): validate_request(frame)
    def test_http_auth_and_request(self):
        server=ThreadingHTTPServer(('127.0.0.1',0),make_handler(self.bridge,'test-token'))
        threading.Thread(target=server.serve_forever,daemon=True).start()
        url=f'http://127.0.0.1:{server.server_port}/api/request'
        try:
            data=json.dumps({'frame':request(1)}).encode()
            with self.assertRaises(urllib.error.HTTPError): urllib.request.urlopen(urllib.request.Request(url,data=data))
            req=urllib.request.Request(url,data=data,headers={'X-ZP12-Token':'test-token'})
            with urllib.request.urlopen(req) as response: self.assertIn('frame',json.load(response))
        finally:
            server.shutdown();server.server_close()

if __name__=='__main__': unittest.main()
