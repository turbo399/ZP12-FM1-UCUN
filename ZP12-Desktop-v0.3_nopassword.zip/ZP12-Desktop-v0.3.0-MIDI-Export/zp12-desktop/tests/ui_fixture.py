"""UI test server using a simulated MIDI port. Not a hardware test."""
from test_bridge import FakeMidi, MidiBridge, ThreadingHTTPServer, make_handler
server=ThreadingHTTPServer(('127.0.0.1',18765),make_handler(MidiBridge(FakeMidi()),'ui-test'))
print('UI test server ready',flush=True)
server.serve_forever()
