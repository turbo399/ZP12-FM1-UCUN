#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-only
"""ZP12 standalone desktop window, using the established Linux MIDI bridge."""
import os
import secrets
import sys
import threading
from pathlib import Path

from PySide6.QtCore import QStandardPaths, QTimer, QUrl
from PySide6.QtGui import QAction, QDesktopServices, QIcon
from PySide6.QtWidgets import QApplication, QFileDialog, QMainWindow, QMessageBox, QInputDialog
from PySide6.QtWebEngineCore import QWebEnginePage, QWebEngineProfile, QWebEnginePermission
from PySide6.QtWebEngineWidgets import QWebEngineView
from app import MidiBridge, ThreadingHTTPServer, make_handler

ROOT = Path(__file__).resolve().parent


class Page(QWebEnginePage):
    def __init__(self, profile, parent, port):
        super().__init__(profile, parent)
        self.port = port

    def local(self, url):
        return url.scheme() == 'http' and url.host() == '127.0.0.1' and url.port() == self.port

    def acceptNavigationRequest(self, url, kind, main_frame):
        if self.local(url) or url.scheme() in ('about', 'blob', 'data'):
            return True
        if main_frame and kind == QWebEnginePage.NavigationType.NavigationTypeLinkClicked:
            QDesktopServices.openUrl(url)
        return False


class Window(QMainWindow):
    def __init__(self, bridge):
        super().__init__()
        self.setWindowTitle('ZP12 Sample Manager')
        self.setWindowIcon(QIcon(str(ROOT / 'icon.svg')))
        self.resize(1160, 900)
        self.closing = False
        self.bridge = bridge
        self.token = secrets.token_urlsafe(24)
        self.server = ThreadingHTTPServer(('127.0.0.1',0),make_handler(bridge,self.token))
        self.thread = threading.Thread(target=self.server.serve_forever,daemon=True)
        self.thread.start()
        self.base = f'http://127.0.0.1:{self.server.server_port}'
        # An off-the-record profile: no external browser session or saved credentials.
        self.profile = QWebEngineProfile(self)
        self.profile.downloadRequested.connect(self.download)
        self.view = QWebEngineView(self)
        self.page = Page(self.profile,self.view,self.server.server_port)
        self.page.permissionRequested.connect(self.permission)
        self.view.setPage(self.page)
        self.setCentralWidget(self.view)
        self.view.loadFinished.connect(self.loaded)
        menu = self.menuBar().addMenu('&File')
        for label,path in [('Sample editor','/'),('Backup / restore','/backup.html')]:
            action = QAction(label,self)
            action.triggered.connect(lambda checked=False,p=path:self.navigate(p))
            menu.addAction(action)
        midi_action=QAction('Export loop as MIDI…',self)
        midi_action.triggered.connect(self.export_midi)
        menu.addAction(midi_action)
        menu.addSeparator()
        quit_action=QAction('Quit',self);quit_action.setShortcut('Ctrl+Q')
        quit_action.triggered.connect(self.close);menu.addAction(quit_action)
        help_menu=self.menuBar().addMenu('&Help')
        about=QAction('About',self)
        about.triggered.connect(lambda:QMessageBox.about(self,'ZP12 Sample Manager',
            'ZP12 Sample Manager 0.3.0\nLinux desktop edition\n\n'
            'Sample editor and protocol by Sven Trogus (@zvenson).\n'
            'Desktop window and Linux MIDI bridge additions.\nGPL-3.0-only.'))
        help_menu.addAction(about)
        self.statusBar().showMessage('Choose the FM-1 input and output, then Connect.')
        self.navigate('/')

    def navigate(self,path):
        def go(active):
            if active:
                QMessageBox.information(self,'Transfer in progress','Wait for the current operation to finish.')
            else:
                self.view.setUrl(QUrl(self.base+path+'?token='+self.token))
        self.page.runJavaScript("typeof busy !== 'undefined' && busy",go)

    def export_midi(self):
        from midi_export import read_project, export_loop, warnings_for
        source,_=QFileDialog.getOpenFileName(self,'Choose a saved ZP12 backup',
            QStandardPaths.writableLocation(QStandardPaths.StandardLocation.DownloadLocation),
            'ZP12 backup (*.zp12bak);;All files (*)')
        if not source:return
        try:
            project=read_project(Path(source).read_bytes())
            available=[i for i,loop in enumerate(project.loops) if loop.hits]
            if not available:raise ValueError('No recorded notes in this backup. SAVE the FM-1, then make a new backup.')
            labels=[f'Loop {i+1} — {project.loops[i].bars} bars, {len(project.loops[i].hits)} hits' for i in available]
            chosen,ok=QInputDialog.getItem(self,'Export loop',f'Tempo: {project.bpm10/10:g} BPM. Choose loop:',labels,0,False)
            if not ok:return
            index=available[labels.index(chosen)]
            mode,ok=QInputDialog.getItem(self,'MIDI tracks','Choose arrangement:',
                ['Separate tracks for each pad (same MIDI channel 1)','One track for the whole kit (MIDI channel 1)'],0,False)
            if not ok:return
            dest,_=QFileDialog.getSaveFileName(self,'Save loop as MIDI',
                str(Path(source).with_name(Path(source).stem+f'-loop-{index+1}.mid')),'MIDI files (*.mid)')
            if not dest:return
            target=Path(dest)
            if not target.suffix:target=target.with_suffix('.mid')
            if target.resolve()==Path(source).resolve():raise ValueError('Choose a different name; do not overwrite the backup.')
            target.write_bytes(export_loop(project,index,split=mode.startswith('Separate')))
            notes=warnings_for(project.loops[index])
            self.statusBar().showMessage('MIDI saved: '+str(target))
            QMessageBox.information(self,'Loop exported',
                'Saved '+str(target)+'\n\nImport this MIDI file into LMMS. Set imported tracks to MIDI output: zp12 FM-1, channel 1. '
                'The file contains notes, tempo, velocities and swing timing, not audio or effects.'+
                ('\n\n'+'\n'.join(notes) if notes else ''))
        except (OSError,ValueError) as e:
            QMessageBox.warning(self,'Cannot export loop',str(e))

    def loaded(self,ok):
        if not ok:
            self.statusBar().showMessage('Could not load the local editor. Restart the app.')

    def permission(self,request):
        if not self.page.local(request.origin()):
            request.deny();return
        if request.permissionType() == QWebEnginePermission.PermissionType.MediaAudioCapture:
            answer=QMessageBox.question(self,'Audio input',
                'Allow the sample editor to record from your microphone or audio interface?',
                QMessageBox.StandardButton.Yes|QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No)
            if answer == QMessageBox.StandardButton.Yes:
                request.grant();return
        request.deny()

    def download(self,request):
        downloads=QStandardPaths.writableLocation(QStandardPaths.StandardLocation.DownloadLocation)
        name=Path(request.suggestedFileName()).name or 'zp12-backup.zp12bak'
        path,_=QFileDialog.getSaveFileName(self,'Save ZP12 file',str(Path(downloads)/name),'All files (*)')
        if not path:
            request.cancel();return
        dest=Path(path)
        request.setDownloadDirectory(str(dest.parent))
        request.setDownloadFileName(dest.name)
        self.statusBar().showMessage('Saving '+dest.name+'…')
        def changed():
            if request.isFinished():
                completed = request.state() == request.DownloadState.DownloadCompleted
                self.statusBar().showMessage(('Saved: ' if completed else 'Download did not complete: ')+str(dest))
        request.isFinishedChanged.connect(changed)
        request.accept()

    def closeEvent(self,event):
        if self.closing:
            event.accept();return
        event.ignore()
        def checked(active):
            if active or self.bridge.lock.locked():
                QMessageBox.information(self,'Transfer in progress','Wait for the current operation to finish before closing.')
                return
            self.closing=True
            self.server.shutdown();self.server.server_close()
            self.thread.join(timeout=2)
            self.bridge.close()
            self.close()
        self.page.runJavaScript("typeof busy !== 'undefined' && busy",checked)


def main():
    app=QApplication(sys.argv)
    app.setApplicationName('ZP12 Sample Manager')
    app.setDesktopFileName('zp12-sample-manager')
    try:
        bridge=MidiBridge();bridge.ports()
    except Exception as e:
        QMessageBox.critical(None,'MIDI unavailable',str(e)+'\n\nCheck Linux ALSA MIDI support and your USB connection.')
        return 1
    window=Window(bridge)
    window.show()
    code=app.exec()
    if not window.closing:
        window.server.shutdown();window.server.server_close();window.bridge.close()
    import shiboken6
    shiboken6.delete(window.page)
    shiboken6.delete(window.profile)
    return code


if __name__ == '__main__':
    sys.exit(main())
