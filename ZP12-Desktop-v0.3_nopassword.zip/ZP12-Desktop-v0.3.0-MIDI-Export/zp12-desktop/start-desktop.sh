#!/usr/bin/env bash
set -e
cd -- "$(dirname -- "$0")"
mkdir -p "${XDG_STATE_HOME:-$HOME/.local/state}/zp12-sample-manager"
log_path="${XDG_STATE_HOME:-$HOME/.local/state}/zp12-sample-manager/desktop.log"
if ! .venv/bin/python desktop.py "$@" >>"$log_path" 2>&1; then
  if command -v zenity >/dev/null; then
    zenity --error --title="ZP12 Sample Manager" --text="Could not start ZP12. Details are in: $log_path"
  else
    printf 'Could not start ZP12. See %s\n' "$log_path" >&2
  fi
  exit 1
fi
