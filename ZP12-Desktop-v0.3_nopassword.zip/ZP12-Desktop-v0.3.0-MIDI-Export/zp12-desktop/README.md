# ZP12 Sample Manager — Linux Desktop

**Version 0.3.0.** A standalone desktop window for the M-VAVE FM-1 running ZP12.
No external browser tabs or terminal are needed after installation. Uses
PySide6/Qt WebEngine for the existing editor and Python RTMidi for Linux MIDI.
The Qt runtime is downloaded once during setup, not bundled in this source ZIP.

## Install on Pop!_OS / Ubuntu (x86-64)

Extract this folder, open a terminal inside it, then run:

```bash
sudo apt install python3-venv libxcb-cursor0 libxkbcommon-x11-0 libegl1
bash install.sh
```

First installation downloads Python MIDI dependencies and Qt (several hundred MB).
Wait until it says **Installed**. Do not run the installer with sudo.
Then search Applications for **ZP12 Sample Manager** and pin its icon if desired.
Close older browser-edition windows and their terminal servers before connecting.

The installer copies the app into `~/.local/share/zp12-sample-manager`, creates its
own virtual environment, and replaces the previous ZP12 menu shortcut. You can move
or remove the extracted source folder afterwards. Your FM-1, WAVs and backups are
not modified by installation. If set, `XDG_DATA_HOME` is used instead.
Re-run `bash install.sh` from a newer release to update. Normal use works offline.

## First connection

1. Connect the FM-1 by USB, running ZP12 normally, not download mode.
2. Close M-Flasher, LMMS and other MIDI editors.
3. Choose the FM-1 input AND output, then Connect the FM-1.
4. Use File → Backup / restore to back up before changing samples.
5. Upload a short test sound, play it, save while stopped and test after power off/on.

If the ports say Midi Through, choose the FM-1. If absent, check the USB data cable,
restart the FM-1 normally, then Refresh ports and reconnect.

## Export your programmed loop to LMMS

No firmware update is needed. This reads an existing backup without changing the FM-1.

1. Stop playback on ZP12, press SAVE and wait for saving to finish.
2. Make a fresh backup including **ZP12** from File → Backup / restore.
3. Choose **File → Export loop as MIDI…** and open that `.zp12bak` file.
4. Select a loop. Only loops with saved hits are listed; numbers match ZP12 loops 1–16.
5. Choose separate tracks per pad, or one track for the whole kit. Both use channel 1.
6. Save the `.mid`, then import it in LMMS using File → Import.
7. Set the imported instrument tracks' MIDI outputs to **zp12 FM-1** and enable MIDI output.
   Silence/unload any internal LMMS instruments if they also play.
8. Keep the FM-1's internal sequencer stopped; LMMS will play its sample pads.

Exports loop length, 96 PPQ note timing, tempo, recorded velocity levels and the
firmware's swing timing. Notes 36–67 address pads A1–D8. The MIDI contains no audio;
the FM-1 must keep the same kit and pad assignments. Effects, per-hit parameter
locks and MULTI PITCH transpositions are not transferred; warnings appear if the
chosen loop uses locks or transposed hits. No new quantization is applied.
MIDI note lengths are short trigger gates; they do not encode the sample tails.
Full ZP12 song-chain export is not implemented.

The exporter targets ZP12 2.5 save layouts (versions 4–6) from the documented source
revision. Older kit layouts have not been validated. It checks backup/store CRCs
and uses the newest valid saved copy; it never uses unsaved live edits.

Command-line export (standard Python only):

```bash
python3 midi_export.py MyKit.zp12bak                 # list nonempty loops
python3 midi_export.py MyKit.zp12bak --loop 1 --output MyLoop.mid
```

## Features

- Sample listing, memory display, WAV export, deletion and pad assignment.
- File import, trimming, previews and normalization.
- 12-bit conversion at 26.04/27.5 kHz, 45→33 and ×2 storage modes.
- Chopping breaks across pads and assigning chop groups.
- Microphone/interface recording, with a native permission prompt.
- ZP12 `.zp12bak` backup/restore; native Save As dialogs for exports.
- Optional sample space in the sloopDX DX7 bank area; bank backup prompt retained.
- Closing or changing pages is blocked while the editor reports an active transfer.

Each upload uses a new sample slot, up to 24. Delete unwanted duplicates to free
slots. Factory sounds are separate from custom sample memory. Deletion is not a
secure erase and does not reset patterns.

The app embeds the editor; an internal loopback service carries MIDI locally.
It binds only to 127.0.0.1, requires a random per-launch token and stops on closing.
No firmware or bootloader flashing is implemented. Optional external help links
open in your browser only when clicked.

## Troubleshooting

- Startup log: `~/.local/state/zp12-sample-manager/desktop.log` (or XDG_STATE_HOME).
- For visible errors run:
  `~/.local/share/zp12-sample-manager/.venv/bin/python ~/.local/share/zp12-sample-manager/desktop.py`
- Missing xcb libraries: install `libxcb-icccm4 libxcb-image0 libxcb-keysyms1 libxcb-render-util0 libxcb-xinerama0` with apt.
- ALSA unavailable: check `aconnect -l`; if `/dev/snd/seq` is absent, try `sudo modprobe snd-seq-midi`. Do not run as root.
- MIDI wheel unavailable: install `build-essential python3-dev libasound2-dev libjack-jackd2-dev` and rerun setup.
- Firmware must support your flash chip; the app cannot fix firmware saving.
- Previous browser mode remains available from source with `bash launch.sh`.

## Tests

```bash
python3 -m unittest discover -s tests -v
# PySide6 required; simulated MIDI only:
QT_QPA_PLATFORM=offscreen QTWEBENGINE_CHROMIUM_FLAGS='--no-sandbox --disable-gpu' python3 tests/desktop_smoke.py
```

Those Chromium flags are for headless testing only. Normal desktop startup keeps
the standard Qt WebEngine sandbox settings. See VALIDATION.md for limits.

## GitHub

Upload the contents of this folder to a repository such as
`zp12-linux-sample-manager`. Include source, web, tests, LICENSE and scripts.
`.gitignore` excludes virtual environments and caches. Keep personal WAVs and
backups separate from the repository.

## Credits and licence

GPL-3.0-only. Editor, backup page and protocol in web derive from
[ZP12 by Sven Trogus (@zvenson)](https://github.com/zvenson/zp12), revision
`a7cc3dcf3b59303024dcfb69f34aac98007425c5`. Original notices are retained.
Desktop shell, installer and local MIDI transport are additions; upstream tracking
scripts are removed. No affiliation or endorsement by M-VAVE or the upstream author.
PySide6/Qt and MIDI dependencies retain their own licences and are installed
separately rather than bundled in this source distribution.
