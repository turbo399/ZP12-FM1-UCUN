#!/usr/bin/env python3
"""Exercise the actual HAL predicate; require all three entry paths to use it."""
import pathlib, re, subprocess, tempfile
root = pathlib.Path(__file__).resolve().parents[1]
h = (root / 'firmware/hal/fm1_flash.h').read_text()
m = re.search(r'RAMINL int fl_jedec_supported\(uint32_t id\)\s*\{[^}]*\}', h)
assert m, 'missing shared flash-ID predicate'
for file, expression in [
 ('firmware/src/zp12.c', 'fl_jedec_supported(FL_FAR(fl_jedec_ram)())'),
 ('firmware/src/recovery.c', 'fl_jedec_supported(FL_FAR(fl_jedec_ram)())'),
 ('firmware/loader/loader.c', 'fl_jedec_supported(fl_jedec_ram())')]:
 s = (root / file).read_text()
 assert expression in s, file
 assert not re.search(r'==\s*0x856014', s), file
program = '#include <stdint.h>\n' + m.group().replace('RAMINL', 'static inline') + '''
int main(void) {
 for (uint32_t id=0; id<0x1000000u; ++id) {
  int want=(id==0x856014u || id==0xB36014u);
  if (fl_jedec_supported(id)!=want) return 1;
 }
 return fl_jedec_supported(0xffffffffu) || fl_jedec_supported(0x1856014u);
}
'''
with tempfile.TemporaryDirectory() as d:
 p = pathlib.Path(d)
 (p/'test.c').write_text(program)
 subprocess.run(['cc','-O2','-Wall','-Werror',str(p/'test.c'),'-o',str(p/'test')],check=True)
 subprocess.run([str(p/'test')],check=True)
print('PASS: all 24-bit IDs checked; only Puya/UCUN accepted; all three gates use predicate')
